# PMAI-Agent

面向应届生的企业发现与招聘线索调查项目。从公开企业来源扩大候选范围，保留岗位线索的依据与未知项，供使用者自行决定下一步。

首个场景：深圳 Agent 开发、大模型应用及相关 FDE 机会。与现有招聘软件互补，不自动投递、修改简历或承诺录用，也不声称找全城市所有机会。

## 已有能力

可使用Python命令行严格解析指定布局的PDF企业名单，保存来源快照、查询原始行，并导入SQLite前三张表。企业调查、模型、搜索与界面属于后续设计。当前阶段、验收状态与待决事项统一见[TODO](TODO.md)；已有检查事实见[B组验收记录](docs/B组验收记录.md)。

## 快速开始

需要Python 3.12与uv；从仓库根目录执行。运行依赖记录在uv.lock，构建器hatchling固定为1.27.0；首次安装需要网络。导入和共享检查离线执行，无需.env、模型账户或作者的研究材料。

```powershell
uv sync --frozen
uv run --frozen python -m unittest discover -s tests -v
```

## 导入和回查

当前适配“一行序号＋企业名称”的深圳2025名单文本布局，不是任意PDF表格解析器。原始材料不随仓库分发。先将下面的路径、出处引用和总数改为自己的受支持材料；`--source`只保存使用者提供的引用，不联网核实附件关系。

```powershell
uv run --frozen pmai-agent import-pdf '<本地PDF路径>' --source '<可回查的出处URL或引用>' --expected-count <已知总数>
uv run --frozen pmai-agent locate '<导入输出的document_id>' <名单序号>
```

`import-pdf`输出document_id、文件SHA-256、解析版本、行数及诊断。默认数据库为`data/app.sqlite3`；PDF字节与逐页文本按哈希保存在`data/content/`，便于原件移动后回查。这些本地副本、数据库和验证输出均被Git忽略；原始文件保持原位。可以在子命令之前使用`--db`、`--content-dir`指定位置，使用者自行保证自定义位置不公开。

同一出处、文件字节、解析版本和observation复用快照；`observation`默认为`initial`。明确记录另一次观察时换一个标识，旧快照保留。acquired_at是本次本地登记时间，不是原下载时间或发布日期。不同来源/观察中的同名不会自动合并；同一名单中的重名保留为空关联、待消歧，其他行建立各自未核实的候选公司。

未识别行、空白/扫描页、断号、重复号、乱序或数量不符会使整份名单拒绝落库；失败快照、已提取文本及页/行诊断保留。页码为PDF物理页，行号对应保存文本的splitlines()位置；提取前失败的诊断页码为0。已有失败观察保持失败，修正依赖或验收数量后用新observation重试。重复导入的新验收失败不改写原成功快照，`issues`给出本次问题，`stored_status`和`stored_issues`给出保存状态。退出码：0成功、2解析/验收失败、1文件或存储操作错误。

已知总数时应提供`--expected-count`：连续序号本身不能发现尾部整段缺失，也不能证明每个文字都准确。AES空密码PDF受支持；扫描件、DOCX、需非空密码、折行和其他版式暂不支持，会显式失败，不自动拼接或OCR。

## 可选：本机环境与指定材料复核

本节不是通用快速开始的前提。历史检查环境为Windows、CPython 3.12.14，其他环境未据此验证。解释器不在PATH时可自行指定；缓存可放到已忽略的tmp目录。网络需要代理时使用自己的代理配置，作者本地端口为65532。

```powershell
$env:UV_CACHE_DIR = Join-Path (Get-Location) 'tmp/uv-cache'
# 仅在需要时设置，并替换为自己的路径与代理
$env:HTTPS_PROXY = 'http://127.0.0.1:65532'
uv sync --frozen --python '<本机Python 3.12解释器路径>'
```

指定材料复核脚本只接受已知哈希和规模的深圳2025名单，不是任意文件验证器。须自行取得对应材料；作者本地路径为`F:\GitHub开源参与计划\2025深圳专精特新企业.pdf`，其他机器替换为自己的路径。官方URL仍只是待核实的出处引用：

```powershell
uv run --frozen python tests/verify_local.py '<指定深圳2025名单PDF路径>' --source 'https://zxqyj.sz.gov.cn/gkmlpt/content/12/12595/post_12595049.html'
```

复核脚本检查既定哈希、名单规模、序号、非深圳前缀保留、重复导入、文本定位与SQLite完整性，输出被忽略的`data/local-validation.json`。历史结果与有限人工抽查见[B组验收记录](docs/B组验收记录.md)；渲染工具不是运行依赖。以上`uv run`命令是基于现有入口整理的用法，不表示已新增跨平台运行验证。

## 从这里开始

- [需求与验收](docs/需求.md)
- [模块职责与流程](docs/开发设计.md)
- [数据关系与首轮落库范围](docs/数据模型.md)
- [当前任务](TODO.md) · [协作入口](AGENTS.md) · [变化记录](CHANGELOG.md)

书稿、课程、作者私人背景与完整研究资料在独立工作区维护，不作为运行本项目的依赖。开源许可证尚未选定，本仓库未复制第三方Skill脚本。
