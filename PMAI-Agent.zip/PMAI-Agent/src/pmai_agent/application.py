"""Import use case; external I/O is supplied by adapters."""

from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from typing import Protocol

from .domain import PARSER_VERSION, Issue, ParsedList, parse_pages


@dataclass(frozen=True)
class ImportRequest:
    path: Path
    source: str
    observation: str = "initial"
    expected_count: int | None = None

    def __post_init__(self):
        if not self.source.strip() or not self.observation.strip():
            raise ValueError("Source and observation must be non-empty")
        if self.expected_count is not None and self.expected_count < 1:
            raise ValueError("Expected count must be positive")


class Extractor(Protocol):
    def extract(self, content: bytes) -> list[str]: ...


class ExtractionError(ValueError):
    def __init__(self, detail: str, page_no: int, pages: list[str]):
        super().__init__(detail)
        self.page_no = page_no
        self.pages = pages


class Repository(Protocol):
    def save(self, request: ImportRequest, digest: str, content: bytes,
             pages: list[str], parsed: ParsedList) -> dict: ...


def import_document(request: ImportRequest, extractor: Extractor, repository: Repository) -> dict:
    # Read once: hash, extraction and archived bytes always describe the same content.
    content = request.path.read_bytes()
    digest = sha256(content).hexdigest()
    try:
        pages = extractor.extract(content)
    except ExtractionError as exc:
        pages = exc.pages
        parsed = ParsedList((), (Issue("pdf_extraction", exc.page_no, 0, "", str(exc)),))
    except Exception as exc:
        pages = []
        parsed = ParsedList((), (Issue("pdf_extraction", 0, 0, "",
                                        f"{type(exc).__name__}: {exc}"),))
    else:
        parsed = parse_pages(pages, request.expected_count)
    result = repository.save(request, digest, content, pages, parsed)
    result.update(parser_version=PARSER_VERSION, sha256=digest,
                  page_count=len(pages), parsed_rows=len(parsed.entries),
                  issues=parsed.diagnostics())
    return result
