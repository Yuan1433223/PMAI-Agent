from io import BytesIO

from pypdf import PdfReader

from ..application import ExtractionError


class PdfExtractor:
    def extract(self, content: bytes) -> list[str]:
        reader = PdfReader(BytesIO(content), strict=True)
        if reader.is_encrypted and not reader.decrypt(""):
            raise ValueError("PDF requires a password; password input is unsupported")
        pages = []
        for page_no in range(1, len(reader.pages) + 1):
            try:
                pages.append(reader.pages[page_no - 1].extract_text() or "")
            except Exception as exc:
                raise ExtractionError(f"{type(exc).__name__}: {exc}", page_no, pages) from exc
        return pages
