"""Document and persistence adapters."""
