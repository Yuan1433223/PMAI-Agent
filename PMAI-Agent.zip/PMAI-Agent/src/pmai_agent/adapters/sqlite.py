"""Versioned SQLite storage. Failed snapshots never leave partial source rows."""

from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import sqlite3
from uuid import uuid4

from ..application import ImportRequest
from ..domain import PARSER_VERSION, ParsedList

SCHEMA = (
    """CREATE TABLE document_snapshots (
        id TEXT PRIMARY KEY, kind TEXT NOT NULL CHECK(kind='pdf'),
        source TEXT NOT NULL, original_path TEXT NOT NULL,
        observation TEXT NOT NULL, acquired_at TEXT NOT NULL,
        content_hash TEXT NOT NULL, content_path TEXT NOT NULL,
        text_path TEXT NOT NULL, text_hash TEXT NOT NULL, parser_version TEXT NOT NULL,
        page_count INTEGER NOT NULL CHECK(page_count>=0),
        parse_status TEXT NOT NULL CHECK(parse_status IN ('parsed','failed')),
        diagnostics TEXT NOT NULL,
        UNIQUE(source, content_hash, parser_version, observation)
    )""",
    """CREATE TABLE companies (
        id TEXT PRIMARY KEY, name TEXT NOT NULL,
        identity_status TEXT NOT NULL DEFAULT 'pending' CHECK(identity_status IN ('pending','confirmed')),
        verified_aliases TEXT NOT NULL DEFAULT '[]'
    )""",
    """CREATE TABLE source_entries (
        id TEXT PRIMARY KEY, document_id TEXT NOT NULL REFERENCES document_snapshots(id),
        row_no INTEGER NOT NULL CHECK(row_no>0), raw_name TEXT NOT NULL,
        page_no INTEGER NOT NULL CHECK(page_no>0), line_no INTEGER NOT NULL CHECK(line_no>0),
        raw_line TEXT NOT NULL, company_id TEXT REFERENCES companies(id),
        link_status TEXT NOT NULL CHECK(link_status IN ('pending','candidate','confirmed')),
        CHECK((link_status='pending' AND company_id IS NULL) OR
              (link_status IN ('candidate','confirmed') AND company_id IS NOT NULL)),
        UNIQUE(document_id, row_no)
    )""",
    "CREATE INDEX source_entries_company ON source_entries(company_id)",
)


def connect(db: Path) -> sqlite3.Connection:
    db.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(db)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    try:
        with connection:
            # Serialize first-run migrations as well as subsequent writes.
            connection.execute("BEGIN IMMEDIATE")
            version = connection.execute("PRAGMA user_version").fetchone()[0]
            if version == 0:
                for statement in SCHEMA:
                    connection.execute(statement)
                connection.execute("PRAGMA user_version=1")
            elif version != 1:
                raise ValueError(f"Unsupported database schema {version}; expected 1")
    except Exception:
        connection.close()
        raise
    return connection


def write_once(path: Path, content: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with path.open("xb") as stream:
            stream.write(content)
    except FileExistsError:
        if path.read_bytes() != content:
            raise ValueError(f"Archive integrity mismatch: {path}")


class SqliteRepository:
    def __init__(self, db: Path, content_dir: Path):
        self.db = db
        self.content_dir = content_dir.resolve()

    def save(self, request: ImportRequest, digest: str, content: bytes,
             pages: list[str], parsed: ParsedList) -> dict:
        identity = json.dumps([request.source, digest, PARSER_VERSION, request.observation],
                              ensure_ascii=False)
        document_id = sha256(identity.encode()).hexdigest()
        content_path = self.content_dir / f"{digest}.pdf"
        text_bytes = json.dumps(pages, ensure_ascii=False, indent=2).encode("utf-8")
        text_hash = sha256(text_bytes).hexdigest()
        text_path = self.content_dir / f"{digest}.{PARSER_VERSION}.{text_hash}.json"
        write_once(content_path, content)
        write_once(text_path, text_bytes)
        connection = connect(self.db)
        try:
            with connection:
                connection.execute("BEGIN IMMEDIATE")
                old = connection.execute("SELECT * FROM document_snapshots WHERE id=?",
                                         (document_id,)).fetchone()
                if old is not None:
                    # Revalidation failures must be visible, even on a repeated import.
                    # Successful persisted data is not rewritten by a caller's wrong count.
                    if old["parse_status"] == "parsed" and not parsed.issues:
                        stored = [tuple(row) for row in connection.execute(
                            "SELECT row_no,raw_name,page_no,line_no,raw_line FROM source_entries "
                            "WHERE document_id=? ORDER BY row_no", (document_id,))]
                        current = [(e.row_no,e.raw_name,e.page_no,e.line_no,e.raw_line)
                                   for e in parsed.entries]
                        if stored != current or Path(old["text_path"]).read_bytes() != text_bytes:
                            raise ValueError("Parser result changed without a parser version change")
                    return dict(document_id=document_id, reused=True,
                                status="failed" if parsed.issues else old["parse_status"],
                                stored_status=old["parse_status"],
                                stored_issues=json.loads(old["diagnostics"]),
                                imported_rows=connection.execute(
                                    "SELECT count(*) FROM source_entries WHERE document_id=?",
                                    (document_id,)).fetchone()[0])
                status = "failed" if parsed.issues else "parsed"
                connection.execute(
                    "INSERT INTO document_snapshots VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (document_id, "pdf", request.source, str(request.path.resolve()),
                     request.observation, datetime.now(timezone.utc).isoformat(), digest,
                     str(content_path), str(text_path), text_hash, PARSER_VERSION, len(pages), status,
                     json.dumps(parsed.diagnostics(), ensure_ascii=False)))
                if not parsed.issues:
                    # Every source row is a separate unverified candidate. Duplicate
                    # names within this document remain unlinked for manual review.
                    counts: dict[str, int] = {}
                    for entry in parsed.entries:
                        counts[entry.raw_name] = counts.get(entry.raw_name, 0) + 1
                    for entry in parsed.entries:
                        company_id = None
                        if counts[entry.raw_name] == 1:
                            company_id = str(uuid4())
                            connection.execute("INSERT INTO companies(id,name) VALUES (?,?)",
                                               (company_id, entry.raw_name))
                        connection.execute(
                            "INSERT INTO source_entries VALUES (?,?,?,?,?,?,?,?,?)",
                            (f"{document_id}:{entry.row_no}", document_id, entry.row_no,
                             entry.raw_name, entry.page_no, entry.line_no, entry.raw_line,
                             company_id, "candidate" if company_id else "pending"))
                return dict(document_id=document_id, reused=False, status=status,
                            stored_status=status, stored_issues=parsed.diagnostics(),
                            imported_rows=0 if parsed.issues else len(parsed.entries))
        finally:
            connection.close()

    def locate(self, document_id: str, row_no: int) -> dict:
        connection = connect(self.db)
        try:
            row = connection.execute(
                "SELECT e.*, d.source,d.content_hash,d.content_path,d.text_path,d.text_hash,d.parser_version "
                "FROM source_entries e JOIN document_snapshots d ON d.id=e.document_id "
                "WHERE e.document_id=? AND e.row_no=?", (document_id, row_no)).fetchone()
            if row is None:
                raise ValueError("Source entry not found")
            result = dict(row)
            content = Path(result["content_path"]).read_bytes()
            if sha256(content).hexdigest() != result["content_hash"]:
                raise ValueError("Archived PDF hash mismatch")
            text_bytes = Path(result["text_path"]).read_bytes()
            if sha256(text_bytes).hexdigest() != result["text_hash"]:
                raise ValueError("Archived text hash mismatch")
            pages = json.loads(text_bytes)
            line = pages[result["page_no"] - 1].splitlines()[result["line_no"] - 1]
            if line != result["raw_line"]:
                raise ValueError("Archived text locator mismatch")
            result["located_line"] = line
            return result
        finally:
            connection.close()
