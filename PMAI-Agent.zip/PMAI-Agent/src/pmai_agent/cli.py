import argparse
import json
import sqlite3
from pathlib import Path
import sys

from .adapters.pdf import PdfExtractor
from .adapters.sqlite import SqliteRepository
from .application import ImportRequest, import_document


def positive_int(value: str) -> int:
    number = int(value)
    if number < 1:
        raise argparse.ArgumentTypeError("Must be positive")
    return number


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Offline, traceable company list import")
    parser.add_argument("--db", type=Path, default=Path("data/app.sqlite3"))
    parser.add_argument("--content-dir", type=Path, default=Path("data/content"))
    commands = parser.add_subparsers(dest="command", required=True)
    ingest = commands.add_parser("import-pdf")
    ingest.add_argument("path", type=Path)
    ingest.add_argument("--source", required=True, help="Retrievable source URL or reference")
    ingest.add_argument("--observation", default="initial")
    ingest.add_argument("--expected-count", type=positive_int)
    locate = commands.add_parser("locate")
    locate.add_argument("document_id")
    locate.add_argument("row_no", type=positive_int)
    args = parser.parse_args(argv)
    repository = SqliteRepository(args.db, args.content_dir)
    try:
        if args.command == "import-pdf":
            result = import_document(ImportRequest(args.path, args.source, args.observation,
                                                   args.expected_count), PdfExtractor(), repository)
        else:
            result = repository.locate(args.document_id, args.row_no)
    except (OSError, ValueError, sqlite3.Error) as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 2 if result.get("status") == "failed" else 0


if __name__ == "__main__":
    raise SystemExit(main())
