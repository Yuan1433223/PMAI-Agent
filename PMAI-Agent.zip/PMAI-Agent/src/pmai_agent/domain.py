"""Pure parsing rules for the Shenzhen 2025 text-list layout."""

from dataclasses import asdict, dataclass
import re

PARSER_VERSION = "sz-2025-text-v1"
TITLE = "2025年深圳市专精特新中小企业名单"


@dataclass(frozen=True)
class Entry:
    row_no: int
    raw_name: str
    page_no: int
    line_no: int
    raw_line: str


@dataclass(frozen=True)
class Issue:
    code: str
    page_no: int
    line_no: int
    text: str
    detail: str


@dataclass(frozen=True)
class ParsedList:
    entries: tuple[Entry, ...]
    issues: tuple[Issue, ...]

    def diagnostics(self) -> list[dict]:
        return [asdict(issue) for issue in self.issues]


def parse_pages(pages: list[str], expected_count: int | None = None) -> ParsedList:
    """Fail closed: only explicit headings and one numbered name per line.

    No prefix filter, name normalization, wrapped-row guessing or OCR fallback.
    Line numbers refer to splitlines() of the stored extracted page text.
    """
    entries, issues = [], []
    if not pages:
        issues.append(Issue("empty_document", 0, 0, "", "No extracted pages"))
    for page_no, page in enumerate(pages, 1):
        if not page.strip():
            issues.append(Issue("empty_page", page_no, 0, "", "OCR or extraction review required"))
        for line_no, raw_line in enumerate(page.splitlines(), 1):
            line = raw_line.strip()
            if not line:
                continue
            if line in ("序号 企业名称", "序号\t企业名称"):
                continue
            if page_no == 1 and line in ("附件1", "附件 1", TITLE):
                continue
            match = re.fullmatch(r"([0-9]+)[ \t]+(\S(?:.*\S)?)", line)
            if not match:
                issues.append(Issue("unrecognized_line", page_no, line_no, raw_line,
                                    "Expected serial number and company name"))
                continue
            row_no, name = int(match[1]), match[2]
            if "\ufffd" in name or not re.search(r"[\u3400-\u9fffA-Za-z]", name):
                issues.append(Issue("invalid_name", page_no, line_no, raw_line,
                                    "Name is unreadable or has no name characters"))
            expected = len(entries) + 1
            if row_no != expected:
                issues.append(Issue("sequence", page_no, line_no, raw_line,
                                    f"Expected {expected}, found {row_no}"))
            entries.append(Entry(row_no, name, page_no, line_no, raw_line))
    if not entries:
        issues.append(Issue("empty_list", 0, 0, "", "No company rows"))
    if expected_count is not None and len(entries) != expected_count:
        issues.append(Issue("count", 0, 0, "",
                            f"Expected {expected_count}, found {len(entries)}"))
    return ParsedList(tuple(entries), tuple(issues))
