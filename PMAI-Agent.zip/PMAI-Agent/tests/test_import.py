from contextlib import redirect_stdout, redirect_stderr
from io import BytesIO, StringIO
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest

from pypdf import PdfReader, PdfWriter
from pypdf.generic import DictionaryObject, NameObject, DecodedStreamObject

from pmai_agent.adapters.pdf import PdfExtractor
from pmai_agent.adapters.sqlite import SqliteRepository, connect
from pmai_agent.application import ExtractionError, ImportRequest, import_document
from pmai_agent.cli import main
from pmai_agent.domain import TITLE, parse_pages


def make_pdf(pages: list[str]) -> bytes:
    """Shareable generated PDF fixture, no local company data or font dependency."""
    writer = PdfWriter()
    for text in pages:
        page = writer.add_blank_page(width=595, height=842)
        font = DictionaryObject({NameObject('/Type'): NameObject('/Font'),
                                 NameObject('/Subtype'): NameObject('/Type1'),
                                 NameObject('/BaseFont'): NameObject('/Helvetica')})
        page[NameObject('/Resources')] = DictionaryObject({NameObject('/Font'):
            DictionaryObject({NameObject('/F1'): writer._add_object(font)})})
        stream = DecodedStreamObject()
        lines = text.splitlines()
        stream.set_data(('BT /F1 12 Tf 20 800 Td 15 TL ' +
                         ' '.join(f'({line}) Tj T*' for line in lines) + ' ET').encode('ascii'))
        page[NameObject('/Contents')] = writer._add_object(stream)
    output = BytesIO()
    writer.write(output)
    return output.getvalue()


class ParserTests(unittest.TestCase):
    def test_chinese_names_and_precise_location(self):
        pages = [f'附件1\n{TITLE}\n序号 企业名称\n1 深圳合成企业有限公司\n2 广东合成企业有限公司',
                 '3 合成（深圳）技术有限公司']
        result = parse_pages(pages, 3)
        self.assertEqual(result.issues, ())
        self.assertEqual(result.entries[1].raw_name, '广东合成企业有限公司')
        self.assertEqual((result.entries[2].page_no, result.entries[2].line_no), (2, 1))

    def test_preserve_name_punctuation_and_internal_spaces(self):
        entry = parse_pages(['1  Acme  Labs（深圳）有限公司  ']).entries[0]
        self.assertEqual(entry.raw_name, 'Acme  Labs（深圳）有限公司')
        self.assertEqual(entry.raw_line, '1  Acme  Labs（深圳）有限公司  ')

    def test_gaps_duplicates_reordering_and_zero_fail(self):
        for text in ['1 Alpha\n3 Beta', '1 Alpha\n1 Beta', '2 Beta\n1 Alpha', '0 Alpha']:
            with self.subTest(text=text):
                self.assertIn('sequence', [i.code for i in parse_pages([text]).issues])

    def test_unknown_wrapped_or_bad_name_lines_fail_with_location(self):
        for bad in ['broken row', '2', '2 123', '2 Bad\ufffdName', 'continued name']:
            with self.subTest(bad=bad):
                result = parse_pages(['1 Alpha', bad])
                self.assertTrue(result.issues)
                self.assertEqual((result.issues[0].page_no, result.issues[0].line_no), (2, 1))
                self.assertEqual(result.issues[0].text, bad)

    def test_empty_or_scanned_page_fails(self):
        for pages in [[], [''], ['1 Alpha', '']]:
            with self.subTest(pages=pages):
                self.assertTrue(parse_pages(pages).issues)

    def test_count_detects_truncated_tail(self):
        self.assertIn('count', [i.code for i in parse_pages(['1 Alpha'], 2).issues])


class ImportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.path = self.root / 'synthetic.pdf'
        self.db = self.root / 'app.sqlite3'
        self.repo = SqliteRepository(self.db, self.root / 'content')
        self.path.write_bytes(make_pdf(['1 Alpha Company\n2 Beta Company', '3 Gamma Company']))

    def ingest(self, **kwargs):
        return import_document(ImportRequest(self.path, kwargs.pop('source', 'synthetic:fixture'),
                                              **kwargs), PdfExtractor(), self.repo)

    def query(self, sql, params=()):
        connection = connect(self.db)
        try:
            return connection.execute(sql, params).fetchall()
        finally:
            connection.close()

    def test_pdf_end_to_end_and_idempotent_import(self):
        first, second = self.ingest(expected_count=3), self.ingest(expected_count=3)
        self.assertEqual(first['status'], 'parsed')
        self.assertEqual(first['document_id'], second['document_id'])
        self.assertTrue(second['reused'])
        self.assertEqual(second['imported_rows'], 3)
        self.assertEqual(self.query('SELECT count(*) FROM document_snapshots')[0][0], 1)
        self.assertEqual(self.query('SELECT count(*) FROM companies')[0][0], 3)
        self.assertEqual(self.query('PRAGMA foreign_key_check'), [])
        self.assertEqual(self.query('PRAGMA integrity_check')[0][0], 'ok')

    def test_locator_survives_original_file_removal(self):
        result = self.ingest()
        self.path.unlink()
        located = self.repo.locate(result['document_id'], 3)
        self.assertEqual(located['page_no'], 2)
        self.assertEqual(located['located_line'], '3 Gamma Company')
        self.assertEqual(located['source'], 'synthetic:fixture')

    def test_duplicate_names_are_pending_and_not_merged(self):
        self.path.write_bytes(make_pdf(['1 Same Company\n2 Same Company\n3 Other Company']))
        self.ingest()
        rows = self.query('SELECT company_id,link_status FROM source_entries ORDER BY row_no')
        self.assertEqual(tuple(rows[0]), (None, 'pending'))
        self.assertEqual(tuple(rows[1]), (None, 'pending'))
        self.assertEqual(self.query('SELECT count(*) FROM companies')[0][0], 1)

    def test_names_across_sources_never_auto_merge(self):
        self.ingest(source='source:A')
        self.ingest(source='source:B')
        self.assertEqual(self.query('SELECT count(*) FROM companies')[0][0], 6)
        self.assertEqual(self.query("SELECT count(*) FROM companies WHERE identity_status='pending'")[0][0], 6)

    def test_new_observation_or_new_bytes_creates_snapshot(self):
        initial = self.ingest()
        observed = self.ingest(observation='second-observation')
        self.path.write_bytes(make_pdf(['1 Alpha Company\n2 New Company']))
        revised = self.ingest()
        self.assertEqual(len({x['document_id'] for x in [initial, observed, revised]}), 3)
        self.assertEqual(self.query('SELECT count(*) FROM source_entries')[0][0], 8)

    def test_failures_preserve_snapshot_and_write_no_partial_rows(self):
        self.path.write_bytes(make_pdf(['1 Alpha\n3 Gamma\nbroken row']))
        result = self.ingest()
        self.assertEqual(result['status'], 'failed')
        self.assertEqual(result['imported_rows'], 0)
        self.assertEqual(self.query('SELECT count(*) FROM companies')[0][0], 0)
        snapshot = self.query('SELECT * FROM document_snapshots')[0]
        issues = json.loads(snapshot['diagnostics'])
        self.assertEqual([i['code'] for i in issues], ['sequence', 'unrecognized_line'])
        self.assertEqual(issues[1]['line_no'], 3)
        self.assertTrue(Path(snapshot['text_path']).exists())

    def test_corrupt_pdf_is_reported_and_archived(self):
        self.path.write_bytes(b'not a PDF')
        result = self.ingest()
        self.assertEqual(result['issues'][0]['code'], 'pdf_extraction')
        self.assertEqual(result['status'], 'failed')
        self.assertEqual(self.query('SELECT count(*) FROM document_snapshots')[0][0], 1)

    def test_empty_password_encryption_can_be_read(self):
        writer = PdfWriter(clone_from=PdfReader(BytesIO(self.path.read_bytes())))
        writer.encrypt('', 'synthetic-owner-password', algorithm='AES-256')
        writer.write(self.path)
        self.assertEqual(self.ingest()['status'], 'parsed')

    def test_password_protected_pdf_fails_explicitly(self):
        writer = PdfWriter(clone_from=PdfReader(BytesIO(self.path.read_bytes())))
        writer.encrypt('synthetic-user-password')
        writer.write(self.path)
        result = self.ingest()
        self.assertEqual(result['status'], 'failed')
        self.assertIn('requires a password', result['issues'][0]['detail'])

    def test_page_extraction_failure_keeps_page_number_and_prior_text(self):
        class BrokenExtractor:
            def extract(self, content):
                raise ExtractionError('synthetic page failure', 2, ['1 Alpha'])
        result = import_document(ImportRequest(self.path, 'synthetic:broken'), BrokenExtractor(), self.repo)
        self.assertEqual(result['issues'][0]['page_no'], 2)
        self.assertEqual(result['imported_rows'], 0)
        snapshot = self.query('SELECT text_path FROM document_snapshots')[0]
        self.assertEqual(json.loads(Path(snapshot[0]).read_text()), ['1 Alpha'])

    def test_count_failure_on_repeat_does_not_hide_or_mutate_success(self):
        first = self.ingest(expected_count=3)
        second = self.ingest(expected_count=4)
        self.assertEqual(second['status'], 'failed')
        self.assertEqual(second['stored_status'], 'parsed')
        self.assertEqual(self.repo.locate(first['document_id'], 1)['raw_name'], 'Alpha Company')

    def test_failed_observation_retained_retry_needs_new_observation(self):
        self.ingest(expected_count=4)
        repeated = self.ingest(expected_count=3)
        self.assertEqual(repeated['stored_status'], 'failed')
        retried = self.ingest(expected_count=3, observation='corrected-validation')
        self.assertEqual(retried['status'], 'parsed')
        self.assertEqual(self.query('SELECT count(*) FROM document_snapshots')[0][0], 2)

    def test_archive_tampering_detected(self):
        result = self.ingest()
        located = self.repo.locate(result['document_id'], 1)
        Path(located['text_path']).write_text('[]', encoding='utf-8')
        with self.assertRaisesRegex(ValueError, 'text hash'):
            self.repo.locate(result['document_id'], 1)
        with self.assertRaisesRegex(ValueError, 'integrity mismatch'):
            self.ingest()

    def test_sql_failure_rolls_back_snapshot_entries_and_companies(self):
        connection = connect(self.db)
        with connection:
            connection.execute("CREATE TRIGGER abort_entries BEFORE INSERT ON source_entries "
                               "BEGIN SELECT RAISE(ABORT, 'injected failure'); END")
        connection.close()
        with self.assertRaises(sqlite3.IntegrityError):
            self.ingest()
        for table in ['document_snapshots', 'source_entries', 'companies']:
            self.assertEqual(self.query(f'SELECT count(*) FROM {table}')[0][0], 0)

    def test_schema_checks_and_unknown_version(self):
        self.ingest()
        connection = connect(self.db)
        with self.assertRaises(sqlite3.IntegrityError):
            connection.execute("INSERT INTO source_entries VALUES ('bad','missing',1,'name',1,1,'line',NULL,'pending')")
        connection.rollback()
        with connection:
            connection.execute('PRAGMA user_version=99')
        connection.close()
        with self.assertRaisesRegex(ValueError, 'Unsupported database schema'):
            connect(self.db)

    def test_cli_success_failure_missing_file_and_locate(self):
        base = ['--db', str(self.db), '--content-dir', str(self.root / 'content')]
        with redirect_stdout(StringIO()) as out:
            self.assertEqual(main(base + ['import-pdf', str(self.path), '--source', 'synthetic:cli']), 0)
        result = json.loads(out.getvalue())
        with redirect_stdout(StringIO()) as out:
            self.assertEqual(main(base + ['locate', result['document_id'], '3']), 0)
        self.assertEqual(json.loads(out.getvalue())['page_no'], 2)
        with redirect_stdout(StringIO()):
            self.assertEqual(main(base + ['import-pdf', str(self.path), '--source', 'synthetic:cli',
                                         '--expected-count', '4']), 2)
        with redirect_stderr(StringIO()):
            self.assertEqual(main(base + ['import-pdf', str(self.root / 'missing.pdf'),
                                         '--source', 'synthetic:cli']), 1)


if __name__ == '__main__':
    unittest.main()
