"""Opt-in check of the local Shenzhen list. Never required by synthetic tests."""

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path

from pmai_agent.adapters.pdf import PdfExtractor
from pmai_agent.adapters.sqlite import SqliteRepository, connect
from pmai_agent.application import ImportRequest, import_document


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('pdf', type=Path)
    parser.add_argument('--source', required=True)
    parser.add_argument('--observation', default='B-verified-2026-10-22')
    parser.add_argument('--db', type=Path, default=Path('data/app.sqlite3'))
    parser.add_argument('--content-dir', type=Path, default=Path('data/content'))
    parser.add_argument('--report', type=Path, default=Path('data/local-validation.json'))
    args = parser.parse_args()
    repo = SqliteRepository(args.db, args.content_dir)
    request = ImportRequest(args.pdf, args.source, args.observation, 2536)
    first = import_document(request, PdfExtractor(), repo)
    second = import_document(request, PdfExtractor(), repo)
    if first['status'] != 'parsed' or second['status'] != 'parsed':
        raise RuntimeError(json.dumps([first, second], ensure_ascii=False))
    assert first['document_id'] == second['document_id'] and second['reused']
    assert first['sha256'] == '94f04587ef1d100b654428fea9119b9f89ae86fe6d84358359577c92df1ff03e'
    assert first['page_count'] == 47
    connection = connect(args.db)
    try:
        rows = connection.execute('SELECT * FROM source_entries WHERE document_id=? ORDER BY row_no',
                                  (first['document_id'],)).fetchall()
        assert [row['row_no'] for row in rows] == list(range(1, 2537))
        assert len({row['raw_name'] for row in rows}) == 2536
        non_shenzhen = sum(not row['raw_name'].startswith('深圳') for row in rows)
        assert non_shenzhen == 302
        # All rows checked against archived page/line text and PDF hash, not just a sample.
        snapshot = connection.execute('SELECT * FROM document_snapshots WHERE id=?',
                                      (first['document_id'],)).fetchone()
        pages = json.loads(Path(snapshot['text_path']).read_text(encoding='utf-8'))
        for row in rows:
            assert pages[row['page_no'] - 1].splitlines()[row['line_no'] - 1] == row['raw_line']
        samples = []
        for row_no in [1, 3, 51, 52, 1262, 1316, 2527, 2536]:
            located = repo.locate(first['document_id'], row_no)
            samples.append(dict(row_no=row_no, page_no=located['page_no'],
                                line_no=located['line_no'], located=True))
        assert connection.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        assert not connection.execute('PRAGMA foreign_key_check').fetchall()
        report = dict(checked_at=datetime.now(timezone.utc).isoformat(),
                      first_import=first, repeated_import=second,
                      non_shenzhen_prefix=non_shenzhen, all_row_locators_checked=len(rows),
                      samples=samples, integrity_check='ok', foreign_key_errors=0,
                      table_counts={table: connection.execute(f'SELECT count(*) FROM {table}').fetchone()[0]
                                    for table in ['document_snapshots','source_entries','companies']},
                      schema_version=connection.execute('PRAGMA user_version').fetchone()[0])
    finally:
        connection.close()
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
